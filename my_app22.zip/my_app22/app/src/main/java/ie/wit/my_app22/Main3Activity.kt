package ie.wit.my_app22


import kotlinx.android.synthetic.main.activity_main3.*
import android.content.Context
import android.database.sqlite.SQLiteOpenHelper
import android.content.ContentValues
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase

//let start by creating database helper class
 class DatabaseHelper(context: Context):
            SQLiteOpenHelper (context, DATABASE_NAME,null,1){

    //OUR ON ONCREATE METHOD CALLED WHEN THE DATABASE IS CREATED

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE $TABLE_NAME (ID INTEGER PRIMARY KEY" +
        "AUTOINCREMENT,NAME TEXT,MATHS TEXT,COMPUTING TEXT)")

        //let create onupgrade method
        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
            db.execSQL("DROP TABLE IF EXISTS" + TABLE_NAME)
            onCreate(db)
        }
        //let insert database
        fun insertData(nam:String, surname:String,marks:String){
            val db = this.writableDatabase
            val contentValues = ContentValues()
            val contentValues.put(col_2,surname)
            val contentValues.put(col_3,surname)
            val contentValues.put(col_4,marks)
            db.insert(TABLE_NAME,null,contentValues)
        }

                //CREATE A METHOD FOR UPDATE
                fun updatesData(id: String, name: String, surname: String, marks: String):
                        Boolean {
                    val db = this.writableDatabase
                    val contentValues = ContentValues()
                    contentValues.put(COL_1 id)
                    contentValues.put(COL_2, name)
                    contentValues.put(COL_3, surname)
                    contentValues.put(COL_4, marks)
                    db.update(TABLE_NAME, contentValues, "ID = ?", arrayOf(id))
                        return true


                                //CREATE A METHOD FOR UPDATE
                        fun deleteData(id : String) : Int {
                            val db = this.writableDatabase
                            return db.delete(TABLE_NAME,"ID = ?, arrayOf(id))

                        }
                        // getter will return to cursor
                    val allData: Cursor
                    get(){
                    val db = this.writableDatabase
                    val res = db.rawQuery("SELETE* FROM" + TABLE_NAME, null)
                    return res

                    }

                    //companion to hold static field

                    companion object {
                        val Data_NAME = "stars.db"
                     val TABLE_NAME = "star.table"
                        val col_1 = "ID"
                         val col_2 = "NAME"
                        val col_3 = "MATHS"
                         val col_4 = "ICOMPUTING"








                            }


                }




    }
}




