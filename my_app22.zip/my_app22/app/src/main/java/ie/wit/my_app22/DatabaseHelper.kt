package ie.wit.my_app22

import android.os.Bundle
import android.support.design.widget.Snackbar
import android.support.v7.app.AlertDialog
import android.support.v7.app.AppCompatActivity

import android.widget.Toast

import kotlinx.android.synthetic.main.activity.*

class DatabaseHelper : AppCompatActivity(){
    /**
     *
     */
    internal var dbHelper = DatabaseHelper(this)
    //internal var dbHelper: DatabaseHelper?=null
    /**
     *let create a function toshow this toast
     */
    fun showToast(text: String){
        Toast.makeText(this, text, Toast.LENGTH_LONG).show()
    }
    /**
     * lets create a function to show the alert an dialog with the data
     */
    fun showDialog(title : String, message : String){//changed from large M
        val builder = AlertDialog.Builder(this)
        builder.setCancelable(true)
        builder.setTitle(title)
        builder.setMessage(message)
        builder.show()
    }
    /**
     * creating a method clear edittexts
     */
    fun clearEditTexts(){
        nameTxt.setText("") //are these fields in your layout????
        idTxt.setText("")
        mathsTxt.setText("")
        compTxt.setText("")
    }
    /**
     * let override oncreate method
     */

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_department)
        //added this
        //init db
        handleInsert()
        handleDeletes() //missing s
        handleUpdates()
        handleViewing()
    }

    /**
     *
     */


    fun handleInsert() {
        insertBtn.setOnClickListener {
            try {
                dbHelper.insertData(nameTxt.text.toString(),mathsTxt.text.toString(),(compTxt.text.toString())
                        clearEditTexts()
            }catch (e : Exception) {
                e.printStackTrace()
                showToast(e.message.toString())
            }
        }
    }
    /**
     * when our handleupdates data button is clicked
     */
    fun handleUpdates() {
        updateBtn.setOnClickListener{//capital O
            try {
                val isUpdate = dbHelper.updateData(
                    R.id.idTxt.toString(), //use the correct format to get the value
                    name.Txt.text.toString(),
                    maths.Txt.text.toString(),
                    comp.Txt.text.toString()
                )
                if (isUdate == true)
                    showToast("Data updated successfully")
                else
                    showToast("Data Not updated")
            }catch (e: Exception){
                e.printStackTrace()
                showToast(e.message.toString())
            }
        }

        /**
         * * when our handleupDelete data button is clicked
         */
        fun handleDeletes() {
            deleteBtn.setonClickListener
            try {
                dbHelper.deleteData(IdTxt.text.toString())
                clearEditTexts()
            }catch (e: Exception){
                e.printStackTrace()
                showToast(e.message.toString())
            }
        }
        /**
         *  when our view All is clicked
         */
        fun handleViewing() {
            viewBtn.setonClickListener(
                view.onClickListener{
                    val res = dbHelper.allData
                    if (res.count == 0){
                        showDialog("Error", "No Data Found")
                        return@onClickListener
                    }
                    val buffer = StringBuffer()
                    while (res.moveToNext()){
                        buffer.append("ID:" + res.get+String (col_0) + "\n")
                        buffer.append("NAME:" + res.get+String(col_1) + "\n")
                        buffer.append("MATHS:" + res.get+String(col_2) + "\n")
                        buffer.append("COMP:" + res.get+String(col_3) + "\n\n")
                    }
                    showDialog ("Data Listener",buffer.toString())
                }
        }



