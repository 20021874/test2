package ie.wit.my_app22

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.content.Intent
import android.widget.Button


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //get reference to the button
        val btn_click_me = findViewById(R.id.computing_Button) as Button
        //set on click listener
        btn_click_me.setOnClickListener {
            val intent = Intent(this, Main2Activity::class.java)
            //start the next activity
            startActivity(intent)
        }
        val btn_click_me2 = findViewById(R.id.Maths_Button) as Button
        //set on click listener
        btn_click_me2.setOnClickListener {
            val intent = Intent(this, Main2Activity::class.java)
            //start the next activity
            startActivity(intent)
        }
        val btn_click_me3 = findViewById(R.id.view_department_Button) as Button
        //set on click listener
        btn_click_me3.setOnClickListener {
            val intent = Intent(this, Main2Activity::class.java)
            //start the next activity
            startActivity(intent)


        }
    }
}


